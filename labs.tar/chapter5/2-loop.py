---
- name: 2. Differenza nella gestione dei LOOP
  hosts: localhost
  connection: local
  gather_facts: no

  tasks:
    - name: "--- TEST 1: INCLUDE + LOOP (Funziona) ---"
      debug: msg="Questo funzionerà perfettamente."

    # Ansible esegue il file 3 volte, una per ogni frutto.
    - include_tasks: external_tasks.yml
      loop:
        - Mela
        - Pera
        - Banana

    - name: "--- TEST 2: IMPORT + LOOP (Fallisce) ---"
      debug: msg="Se scommenti le righe sotto, il playbook CRASHA."

    - name: Questo romperà tutto
      import_tasks: external_tasks.yml
      loop:
        - Errore1
        - Errore2
