---
- name: 1. Differenza nella gestione del WHEN
  hosts: localhost
  connection: local
  gather_facts: no

  vars:
    esegui_task: false 

  tasks:
    - name: "--- TEST 1: IMPORT (Statico) ---"
      debug:
        msg: "Osserva: vedrai il task esterno come 'SKIPPED'"
      

    # Ansible "incolla" il task qui 
    # Risultato: Il task appare nel log, ma viene saltato.
    - import_tasks: external_tasks.yml
      when: esegui_task

    - name: "--- TEST 2: INCLUDE (Dinamico) ---"
      debug: 
          msg: "Osserva: NON vedrai il task esterno nel log"

    # Ansible valuta il when PRIMA di aprire il file.
    # Risultato: Il file non viene nemmeno letto. 
    - include_tasks: external_tasks.yml
      when: esegui_task
