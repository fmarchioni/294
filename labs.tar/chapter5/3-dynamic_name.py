---
- name: 3. Differenza nei Nomi di File Variabili
  hosts: localhost
  connection: local
  gather_facts: no

  tasks:
    - name: Calcolo il nome del file durante l'esecuzione
      set_fact:
        nome_file_calcolato: "external_tasks.yml"

    - name: "--- TEST 1: INCLUDE (Funziona) ---"
      debug: msg="Include risolve la variabile 'nome_file_calcolato' al momento."
    
    - include_tasks: "{{ nome_file_calcolato }}"

    - name: "--- TEST 2: IMPORT (Fallisce) ---"
      debug: msg="Import fallisce perché vuole il nome PRIMA che set_fact giri."

    # SCOMMENTA PER VEDERE L'ERRORE:
    - name: Questo fallirà (o darà warning deprecato)
      import_tasks: "{{ nome_file_calcolato }}"
